<?php

namespace App\Policies;

use App\Models\Message;
use App\Models\MessageRecipient;
use App\Models\User;

class MessagePolicy
{
    public function before(User $user): ?bool
    {

        return $user->isAdmin() ? true : null;
    }

    private function isRecipient(User $user, Message $message): bool
    {
        return $message->recipients()
            ->where('user_id', $user->id)
            ->exists();
    }

    /**
     * Determine whether the user can view any models.
     */
    public function viewAny(User $user): bool
    {
        return $user->isParent();
    }

    /**
     * Determine whether the user can view the model.
     */
    public function view(User $user, Message $message): bool
    {
        return $this->isRecipient($user, $message);
    }

    /**
     * Determine whether the user can create models.
     */
    public function create(User $user): bool
    {
        return false;
    }

    /**
     * Determine whether the user can update the model.
     */
    public function update(User $user, Message $message): bool
    {
        return false;
    }

    /**
     * Determine whether the user can delete the model.
     */
    public function delete(User $user, Message $message): bool
    {
        return false;
    }

    /**
     * Determine whether the user can restore the model.
     */
    public function restore(User $user, Message $message): bool
    {
        return false;
    }

    /**
     * Determine whether the user can permanently delete the model.
     */
    public function forceDelete(User $user, Message $message): bool
    {
        return false;
    }

    /**
     * Determine whether the user can notify recipients the model.
     */
    public function notify(User $user, Message $message, MessageRecipient $recipient): bool
    {
        return $user->isAdmin() && $recipient->message_id === $message->id;
    }
}
